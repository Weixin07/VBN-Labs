﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As New OleDb.OleDbConnection

        Dim dbProvider As String
        Dim dbSource As String

        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim ds As New DataSet

        dbProvider = "Provider = Microsoft.JET.OLEDB.4.0;"
        dbSource = "Data source = LibraryDatabase.mdb"

        con.ConnectionString = dbProvider & dbSource

        con.Open()
        MessageBox.Show("connection opened.")

        sql = "select * from student where studentTP = 'TP04123'"
        da = New OleDb.OleDbDataAdapter(sql, con)
        da.Fill(ds, "studentList")

        TextBox1.Text = ds.Tables("studentList").Rows(0).Item(1)
        TextBox2.Text = ds.Tables("studentList").Rows(0).Item(2)

        con.Close()
        MessageBox.Show("connection closed.")
    End Sub
End Class
